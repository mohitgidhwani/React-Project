import React from 'react'
import { Link, Outlet } from 'react-router-dom'

function SignIn() {
    return (
        <>
            <div>
                <div className="page-heading header-text">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-12">
                                <h3>Sign In</h3>

                            </div>
                        </div>
                    </div>
                </div>
                <div className="contact-page section">
                    <div className="container">
                        <div className="row justify-content-center">

                            <div className="col-lg-6">
                                <div className="right-content">
                                    <div className="row justify-content-center">

                                        <div className="col-lg-12">
                                            <form id="contact-form"  method="post">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <fieldset>
                                                            <input type="name" name="name" id="name" placeholder="Username..." autoComplete="on" required />
                                                        </fieldset>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <fieldset>
                                                            <input type="surname" name="surname"  id="surname" placeholder="Password..." autoComplete="on" required />
                                                        </fieldset>
                                                    </div>



                                                    <div className="col-lg-12 d-flex justify-content-center">
                                                        <fieldset>
                                                            <button type="submit" id="form-submit" className="orange-button">Sign In</button>
                                                        </fieldset>
                                                    </div>
                                                    <div className='text-center pt-5'>
                                                        <span>New to Game Store </span><Link to={'/signup'}>Sign Up</Link>
                                                                                        
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default SignIn